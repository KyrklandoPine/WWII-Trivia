from mainfolder.states import levels, main_menu
from . import setup, tools
from . import constants as c


ROOM_2='room_2'
ROOM_3='room_3'
ROOM_3='room_3'
ROOM_4='room_4'
ROOM_5='room_5'
ROOM_6='room_6'
END='end'
POLAND='Poland'
TREATY_VERSAILLES='treaty_versailles'
ATOMIC_BOMB='atomic_bomb'
NEWS='news'
NUREMBURG='nuremburg'
PEARL_HARBOR='pearl_harbor'
START='start'
MAIN_MENU = 'main menu'
INSTRUCTIONS = 'instructions'

def main():
    """Add states to control here"""
    run_it = tools.Control(setup.ORIGINAL_CAPTION)
    state_dict = {MAIN_MENU: main_menu.Menu(),
                  ROOM_4: levels.LevelState(ROOM_4),
                  ROOM_5: levels.LevelState(ROOM_5),
                  ROOM_6: levels.LevelState(ROOM_6),
                  END: levels.LevelState(END),
                  ROOM_3: levels.LevelState(ROOM_3),
                  POLAND: levels.LevelState(POLAND),
                  START: levels.LevelState(START),
                  TREATY_VERSAILLES: levels.LevelState(TREATY_VERSAILLES),
                  ATOMIC_BOMB: levels.LevelState(ATOMIC_BOMB),
                  NEWS: levels.LevelState(NEWS),
                  NUREMBURG: levels.LevelState(NUREMBURG),
                  PEARL_HARBOR: levels.LevelState(PEARL_HARBOR),
                  ROOM_2: levels.LevelState(ROOM_2),
                  INSTRUCTIONS: main_menu.Instructions(),
                  }

    run_it.setup_states(state_dict, c.MAIN_MENU)
    run_it.main()
