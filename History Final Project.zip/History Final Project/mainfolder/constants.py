#Constants used throughout the game 
SCREEN_SIZE = (1000, 1000)

##GAME STATES
START='start'
MAIN_MENU = 'main menu'
INSTRUCTIONS = 'instructions'
ROOM_2='room_2'
ROOM_3='room_3'
ROOM_4='room_4'
ROOM_5='room_5'
ROOM_6='room_6'
ROOM_7='room_7'
ROOM_8='room_8'
NEWS='news'
ROOM_9='room_9'
ROOM_10='room_10'
ROOM_11='room_11'
ROOM_12='room_12'
ROOM_13='room_13'
ROOM_14='room_14'
POLAND='Poland'
TREATY_VERSAILLES='treaty_versailles'
ATOMIC_BOMB='atomic_bomb'
BATTLE_ATLANTIC='battle_atlantic'
BATTLE_BRITAIN='battle_britain'
BOMBING_OFFENSIVE='bombing_offensive'
CODE_BREAK='code_break'
D_DAY='d_day'
FALL_OF_FRANCE='fall_of_france'
ITALY='italy'
NUREMBURG='nuremburg'
PEARL_HARBOR='pearl_harbor'
STALINGRAD='stalingrad'
US_ENTRY_ALLIANCE='us_entry_alliance'
##Colors

BLACK = 0, 0, 0
NEAR_BLACK = 1, 0, 0
WHITE = 255, 255, 255
BLACK_BLUE = 19, 15, 48
NEAR_BLACK_BLUE = 20, 15, 48
LIGHT_BLUE = 0, 153, 204
DARK_RED = 118, 27, 12
REALLY_DARK_RED = 15, 0, 0
RED = 255, 0, 0
GREEN = 0, 255, 0
PINK = 208, 32, 144
TRANSITION_COLOR = BLACK

MAIN_FONT = 'DroidSans'

#BATTLE STATES

SELECT_ACTION = 'select action'
SELECT_ENEMY = 'select enemy'
ENEMY_ATTACK = 'enemy attack'
SWITCH_ENEMY = 'switch enemy'
PLAYER_ATTACK = 'player attack'
SELECT_ITEM = 'select item'
SELECT_MAGIC = 'select magic'
RUN_AWAY = 'run_away'
ATTACK_ANIMATION = 'attack animation'
BATTLE_WON = 'battle won'
ENEMY_DAMAGED = 'enemy damaged'
ENEMY_DEAD = 'enemy dead'
PLAYER_FINISHED_ATTACK = 'player finished attack'
PLAYER_DAMAGED = 'enemy attack damage'
DRINK_HEALING_POTION = 'drink healing potion'
DRINK_ETHER_POTION = 'drink ether potion'
CURE_SPELL = 'cure spell'
FIRE_SPELL = 'fire spell'
VICTORY_DANCE = 'victory dance'
KNOCK_BACK = 'knock back'
FLEE = 'flee'
FADE_DEATH = 'fade death'
SHOW_EXPERIENCE = 'show experience'
LEVEL_UP = 'level up'
TWO_ACTIONS = 'two actions'
SHOW_GOLD = 'show gold'
DEATH_FADE = 'death fade'

#EVENTS

END_BATTLE = 'end battle'

#SOUND EFFECTS

CLICK = 'click'
CLICK2 = 'click2'
CLOTH_BELT = 'cloth_belt'
SWORD = 'sword'
FIRE = 'fire'
PUNCH = 'punch'
POWERUP = 'powerup'
TALK = 'talk'
MISS = 'whoosh'

TRANSITION_SPEED = 35 
DEATH_TRANSITION_SPEED = 5

#LEVEL STATES

NORMAL = 'normal'
TRANSITION_IN = 'transition in'
TRANSITION_OUT = 'transition out'
