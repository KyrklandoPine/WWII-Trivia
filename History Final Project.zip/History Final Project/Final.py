import sys
import pygame as pg
from mainfolder import setup
from mainfolder.main import main

if __name__ =='__main__':
    setup.GAME
    main()
    pg.quit()
    sys.exit()
